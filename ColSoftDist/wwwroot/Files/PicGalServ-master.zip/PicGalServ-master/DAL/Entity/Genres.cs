﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Entity
{
    public class Genres : CommonEntity
    {
        public string Name { get; set; }
    }
}
