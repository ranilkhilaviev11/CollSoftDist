﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace UchetUspevaemosti
{
    public partial class MainForm : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        SqlCommandBuilder commandBuilder;
        string sql_Progress = "SELECT * FROM Progress";
        string sql_Student = "SELECT * FROM Student";
        string sql_Teacher = "SELECT * FROM Teacher";
        string sql_Group = "SELECT * FROM [Group]";
        string sql_Subject = "SELECT * FROM Subject";
        string sql_Faculty = "SELECT * FROM Faculty";
        string sql_Authorization = "SELECT * FROM [Authorization]";
        string sql_Post = "SELECT * FROM Post";
    
        

        public MainForm()
        {
            InitializeComponent();
            cb_table.DropDownStyle = ComboBoxStyle.DropDownList;


            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AllowUserToAddRows = false;
        }

        private async void DataGridViewData(string sql)
        {
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString))
            {
                await connection.OpenAsync();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
        }
        // кнопка удаления
       private void deleteButton_Click_1(object sender, EventArgs e)
        {
            // удаляем выделенные строки из dataGridView1
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.Remove(row);
            }
        }
        // кнопка добавления
        private void addButton_Click_1(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].NewRow(); // добавляем новую строку в DataTable
            ds.Tables[0].Rows.Add(row);
        }
        // сохранение
        private async void saveButton_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString))
            {
                await connection.OpenAsync();
                adapter = new SqlDataAdapter(sql_Progress, connection);
                commandBuilder = new SqlCommandBuilder(adapter);
                adapter.InsertCommand = new SqlCommand("sp_CreateProgress", connection);
                adapter.InsertCommand.CommandType = CommandType.StoredProcedure;
                adapter.InsertCommand.Parameters.Add(new SqlParameter("@group", SqlDbType.Decimal, 0, "Группа"));
                adapter.InsertCommand.Parameters.Add(new SqlParameter("@subject", SqlDbType.NVarChar, 50, "Предмет"));
                adapter.InsertCommand.Parameters.Add(new SqlParameter("@Teacher", SqlDbType.NVarChar, 50, "Преподаватель"));
                adapter.InsertCommand.Parameters.Add(new SqlParameter("@Student", SqlDbType.NVarChar, 50, "Студент"));
                adapter.InsertCommand.Parameters.Add(new SqlParameter("@Mark", SqlDbType.Int, 0, "Оценка"));
                SqlParameter parameter = adapter.InsertCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
                parameter.Direction = ParameterDirection.Output;
                adapter.Update(ds);
            }
        }

        private void Searching(string search, string sql_search)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDBconnectionString"].ConnectionString))
                {
                    connection.Open();
                    adapter = new SqlDataAdapter(search, connection);

                    ds = new DataSet();
                    adapter.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];
                    connection.Close();
                }


            }
            catch (Exception)
            {
                if (tb_search.Text == "")
                {
                    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDBconnectionString"].ConnectionString))
                    {
                        adapter = new SqlDataAdapter(sql_search, connection);

                        ds = new DataSet();
                        adapter.Fill(ds);
                        dataGridView1.DataSource = ds.Tables[0];
                        connection.Close();
                    }
                }
                else { MessageBox.Show("Не найдено"); }
            }
        }
        // поиск


        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form1 Auth = new Form1();
            Auth.Show();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDBconnectionString"].ConnectionString))
                {
                    string search = "SELECT * FROM Progress WHERE Группа = " + tb_search.Text + "OR Предмет = " +
                        tb_search.Text + "OR Преподаватель = " + tb_search.Text + "OR Студент = " + tb_search.Text +
                        "OR Оценка = " + tb_search.Text + "";
                    connection.Open();
                    adapter = new SqlDataAdapter(search, connection);

                    ds = new DataSet();
                    adapter.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];
                    connection.Close();
                }


            }
            catch (Exception)
            {
                if (tb_search.Text == "")
                {
                    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDBconnectionString"].ConnectionString))
                    {
                        adapter = new SqlDataAdapter(sql_Progress, connection);

                        ds = new DataSet();
                        adapter.Fill(ds);
                        dataGridView1.DataSource = ds.Tables[0];
                        connection.Close();
                    }
                }
                else { MessageBox.Show("Не найдено"); tb_search.Text = ""; }
            }
        }



        private async void MainForm_Load(object sender, EventArgs e)
        {
            
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString))
            {
                await connection.OpenAsync();
                adapter = new SqlDataAdapter(sql_Progress, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                dataGridView1.Columns["ID"].ReadOnly = true;
                /////////////////////////////////////////////////////////////////
                ArrayList row = new ArrayList();
                DataGridViewComboBoxColumn Groups = new DataGridViewComboBoxColumn();
                SqlDataAdapter adapter1 = new SqlDataAdapter("SELECT Группа FROM [Group]", connection);
                DataSet ds1 = new DataSet();
                adapter1.Fill(ds1);
                DataTable dt = new DataTable();
                dt = ds1.Tables[0];
                Groups.HeaderText = "Группы";
                foreach (DataRow dr in dt.Rows)
                {
                    row.Add(dr["Группа"].ToString());
                }
                Groups.Items.AddRange(row.ToArray());
                dataGridView1.Columns.Add(Groups);
            }
            
        }

        private void cb_table_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cb_table.Text)
            {
                case "Успеваемость":
                    DataGridViewData(sql_Progress);
                    dataGridView1.Columns["Id"].ReadOnly = true;
                    break;
                case "Студенты":
                    DataGridViewData(sql_Student);
                    break;
                case "Преподаватели":
                    DataGridViewData(sql_Teacher);
                    break;
                case "Группы":
                    DataGridViewData(sql_Group);
                    break;
                case "Предметы":
                    DataGridViewData(sql_Subject);
                    break;
                case "Факультеты":
                    DataGridViewData(sql_Faculty);
                    break;
                case "Пользователи":
                    DataGridViewData(sql_Authorization);
                    dataGridView1.Columns["Id"].ReadOnly = true;
                    break;
                case "Роли":
                    DataGridViewData(sql_Post);
                    break;

            }
        }
       
    }
}
