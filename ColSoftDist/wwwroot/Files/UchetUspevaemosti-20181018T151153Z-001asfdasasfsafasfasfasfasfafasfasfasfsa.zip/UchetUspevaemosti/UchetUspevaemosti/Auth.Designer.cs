﻿namespace UchetUspevaemosti
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tb_login = new System.Windows.Forms.TextBox();
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_loginWarn = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_loginClose = new System.Windows.Forms.Button();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tb_login
            // 
            resources.ApplyResources(this.tb_login, "tb_login");
            this.tb_login.Name = "tb_login";
            this.tb_login.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_login_KeyDown);
            // 
            // lbl_login
            // 
            resources.ApplyResources(this.lbl_login, "lbl_login");
            this.lbl_login.BackColor = System.Drawing.Color.Transparent;
            this.lbl_login.Name = "lbl_login";
            // 
            // lbl_password
            // 
            resources.ApplyResources(this.lbl_password, "lbl_password");
            this.lbl_password.BackColor = System.Drawing.Color.Transparent;
            this.lbl_password.Name = "lbl_password";
            // 
            // lbl_loginWarn
            // 
            this.lbl_loginWarn.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.lbl_loginWarn, "lbl_loginWarn");
            this.lbl_loginWarn.ForeColor = System.Drawing.Color.Red;
            this.lbl_loginWarn.Name = "lbl_loginWarn";
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.btn_login, "btn_login");
            this.btn_login.Name = "btn_login";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_loginClose
            // 
            this.btn_loginClose.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.btn_loginClose, "btn_loginClose");
            this.btn_loginClose.Name = "btn_loginClose";
            this.btn_loginClose.UseVisualStyleBackColor = false;
            this.btn_loginClose.Click += new System.EventHandler(this.button2_Click);
            // 
            // tb_password
            // 
            resources.ApplyResources(this.tb_password, "tb_password");
            this.tb_password.Name = "tb_password";
            this.tb_password.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_password_KeyDown);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::UchetUspevaemosti.Properties.Resources.background;
            this.ControlBox = false;
            this.Controls.Add(this.btn_loginClose);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.lbl_loginWarn);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_login);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_login);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_login;
        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_loginWarn;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_loginClose;
        private System.Windows.Forms.TextBox tb_password;
    }
}

