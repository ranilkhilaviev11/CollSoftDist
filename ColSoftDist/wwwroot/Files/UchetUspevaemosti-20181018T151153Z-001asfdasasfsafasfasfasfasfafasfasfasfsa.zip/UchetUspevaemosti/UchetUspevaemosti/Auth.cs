﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace UchetUspevaemosti
{
    public partial class Form1 : Form
    {
        MainForm mainForm = new MainForm();

        public Form1()
        {
            InitializeComponent();
            tb_password.PasswordChar = '*';
            
        }

        private void Authorization()
        {
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString))
            {
                connection.Open();
                SqlCommand aut = new SqlCommand("SELECT COUNT (*) FROM [dbo].[Authorization] WHERE [Логин]= '" + tb_login.Text + "' AND [Пароль] = '" + tb_password.Text + "'", connection);
                int check = Convert.ToInt32(aut.ExecuteScalar());
                if (check == 1)
                {
                    mainForm.Show();
                    this.Hide();
                }
                else { lbl_loginWarn.Visible = true; }
                connection.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            Authorization();
        }

        private void tb_password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                Authorization();
        }

        private void tb_login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                Authorization();
        }
    }
}
