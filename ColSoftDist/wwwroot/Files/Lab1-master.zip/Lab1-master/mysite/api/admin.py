from django.contrib import admin
from .models import PersonInfo


admin.site.register(PersonInfo)

# Register your models here.
